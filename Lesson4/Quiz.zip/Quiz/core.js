let game = {
  run() {
    //Задаем вопрос

    // askQuestions(questions);

    let userAnswer = prompt(questions.q);

    // Если отмена, игра окончена
    if (correctAnswer == undefined) {
      return console.log("Game over");
    }
    // Если правильный ответ, то задавать следующий
    // И прибавлять очко
    if (correctAnswer) {
      score.countTheScore();
      console.log("Correct " + "your score " + score.scoreCounter);
      // qCount++;
      // askQuestions(questions);
    }
    // Если неправильный, задавать дальше, не прибавлять очко
    else {
      console.log("Wrong " + "your score " + score.scoreCounter);
      // qCount++;
      // askQuestions(questions);
    }
  },

  init() {
    console.log("Отвечайе на вопросы и зарабатывайте баллы");
    console.log("Чтобы начать игру наберите game.run() и нажмите Enter");
  }
};

game.init();
