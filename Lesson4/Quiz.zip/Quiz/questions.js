// const questions = {
//   q1:
//     'Сколько букв в слове "привет" \n a. Пять. \n b. Шесть. \n c. Семь. \n d. Куда я попал?',
//   a1: "b"
//
//   // askQuestion() {
//   //   for (let i = 0; i < ; i++) {
//   //
//   //   }
//   // }
// };

const questions = [
  {
    q:
      'Сколько букв в слове "привет" \n a. Пять. \n b. Шесть. \n c. Семь. \n d. Куда я попал?',
    a: "b"
  },
  {
    q:
      'Зимой и летом..." \n a. Одним цветом. \n b. Смерть поэтам. \n c. Съесть котлету. \n d. Где я',
    a: "a"
  },
  {
    q:
      'Из чего делают фуагра?" \n a. Печень. \n b. Почки. \n c. Поджелудочная. \n d. Кто я',
    a: "a"
  },
  {
    q: 'Эй вы там..." \n a.Внизу. \n b. Справа. \n c. Наверху. \n d. Слева',
    a: "c"
  }
];

let correctAnswer = "";
let qCount = 0;
function askQuestions(array) {
  console.log(qCount);
  let userAnswer = prompt(array[qCount].q);
  if (userAnswer == null) {
    correctAnswer = userAnswer;
  }
  if (userAnswer == array[qCount].a) {
    correctAnswer = true;
  } else {
    correctAnswer = false;
  }
}
