let score = {
  scoreCounter: 0,
  countTheScore() {
    return this.scoreCounter++;
  }
};
